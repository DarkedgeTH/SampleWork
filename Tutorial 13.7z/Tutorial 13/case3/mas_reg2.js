"use strict";
/*
   New Perspectives on HTML5, CSS3, and JavaScript 6th Edition
   Tutorial 13
   Case Problem 3


   Filename: mas_reg2.js

   Author: Nicholas Payne  
   Date: 3/25/19


   Function List
   =============
      
   writeSessionValues()
      Writes data values from session storage in to the
      registration summary form


*/

// *step 10*
function writeSessionValues() {
	document.getElementById("regName").innerHTML = sessionStorage.confName;
	document.getElementById("regGroup").innerHTML = sessionStorage.confGroup;
	document.getElementById("regEmail").innerHTML = sessionStorage.confMail;
	document.getElementById("regPhone").innerHTML = sessionStorage.confPhone;
	document.getElementById("regSession").innerHTML = sessionStorage.confSession;
	document.getElementById("regBanquet").innerHTML = sessionStorage.confBanquet;
	document.getElementById("regPack").innerHTML = sessionStorage.confPack;
	document.getElementById("regTotal").innerHTML = sessionStorage.confTotal;
}
// *step 11*
window.addEventListener("load",writeSessionValues);